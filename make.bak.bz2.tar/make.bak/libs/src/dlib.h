

char* dlib_name();
int add(int a, int b);