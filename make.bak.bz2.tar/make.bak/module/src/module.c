#include <stdio.h>
#include "module.h"
#include "func.h"

void module_main()
{
    printf("module_main()::start module ...\n");
    
    foo();
}