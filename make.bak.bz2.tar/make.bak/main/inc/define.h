#ifndef DEFINE_H
#define DEFINE_H

#define VERSION "1.0.0"

#endif
