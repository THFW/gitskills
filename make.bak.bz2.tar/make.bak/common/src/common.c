#include <stdio.h>
#include "common.h"

void common()
{
    printf("void common() ...\n");
}
