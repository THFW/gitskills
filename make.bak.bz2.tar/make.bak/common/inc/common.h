#ifndef COMMON_H
#define COMMON_H

void module_main();
void common();

#endif
